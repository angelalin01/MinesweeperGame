
package minesweeper;

public enum ImageName {
    Empty,
    Covered,
    Marked,
    Wrongmarked,
    Bomb
}
