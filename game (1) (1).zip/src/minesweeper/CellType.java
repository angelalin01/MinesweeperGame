package minesweeper;

public enum CellType {
    Bomb,
    BombNeighbor,
    Empty
}
